# RAGDocForge Output Summary

## Artifacts

- `ragdocforge_outputs/markdown/`: RAG-ready markdown files with YAML front matter.
- `ragdocforge_outputs/chunks.jsonl`: one JSON object per chunk for ingestion.
- `ragdocforge_outputs/quality_report.json`: deterministic quality reports and failed-file records.
- `ragdocforge_outputs/metadata_sidecar.json`: full document-level metadata referenced by chunks.
- `ragdocforge_outputs/llm_analysis_report.json`: optional LLM critique bundles and provider warnings.
- `ragdocforge_outputs/suggested_sections.md`: suggested content additions, when generated.
- `ragdocforge_outputs/manifest.json`: batch metadata and export inventory.
- `ragdocforge_outputs/README_OUTPUTS.md`: guide to the generated artifacts.

## Documents

### journal_import_errors.md

- Document ID: `journal_import_errors`
- ERP module: `GL`
- Document type: `TROUBLESHOOTING_NOTE`
- Quality score: `69`
- Readiness: `NEEDS_IMPROVEMENT`
